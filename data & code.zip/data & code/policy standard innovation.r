#Correlation matrix & VIF
if (!require(readxl)) install.packages("readxl")
if (!require(dplyr)) install.packages("dplyr")
if (!require(corrplot)) install.packages("corrplot")

library(readxl)
library(dplyr)
library(corrplot)
# 
df <- read_excel("GB data.xlsx", sheet = "Sheet1")
str(df)
df <- df %>%
  rename(
    Policy       = `Policy`,
    Standard     = `Standard`,
    IndStructure = `IndStructure`,
    IndUpgrade   = `IndUpgrade`,
    Firm         = `Firm`,
    Prod         = `Prod`,
    Invest       = `Invest`,
    Debt         = `Debt`,
    Profit       = `Profit`,
    RDIntensity  = `RDIntensity`,
    EduStructure = `EduStructure`
  )

df <- df %>%
  mutate(
    lnFirm   = log(Firm),
    lnProd   = log(Prod),
    lnInvest = log(Invest),
    lnDebt   = log(Debt),
    lnProfit = log(Profit),
    Policy_Standard = Policy * Standard
  )

vars_all <- df %>%
  select(
    Policy,
    Standard,
    Policy_Standard,
    IndStructure,
    IndUpgrade,
    lnFirm,
    lnProd,
    lnInvest,
    lnDebt,
    lnProfit,
    RDIntensity,
    EduStructure
  ) %>%
  mutate(across(everything(), as.numeric))

cor_matrix_all <- round(
  cor(vars_all, use = "pairwise.complete.obs"),
  3
)
plot_matrix <- cor_matrix_all

rename_vars <- c(
  "Policy" = "Policy",
  "Standard" = "Standard",
  "Policy_Standard" = "Policy × Standard",
  "IndStructure" = "IndStructure",
  "IndUpgrade" = "IndUpgrade",
  "lnFirm" = "lnFirm",
  "lnProd" = "lnProd",
  "lnInvest" = "lnInvest",
  "lnDebt" = "lnDebt",
  "lnProfit" = "lnProfit",
  "RDIntensity" = "RDIntensity",
  "EduStructure" = "EduStructure"
)

for (old_name in names(rename_vars)) {
  rownames(plot_matrix)[rownames(plot_matrix) == old_name] <- rename_vars[old_name]
  colnames(plot_matrix)[colnames(plot_matrix) == old_name] <- rename_vars[old_name]
}

draw_corrplot <- function(mat) {
  
  par(
    family = "serif",
    mar = c(1, 1, 1, 1)
  )
  
  corrplot(
    mat,
    method = "color",
    type = "upper",
    order = "original",
    diag = FALSE,
    
    col = colorRampPalette(
      c("#2166AC", "white", "#B2182B")
    )(200),
    
    addCoef.col = "black",
    number.cex = 0.65,
    number.digits = 2,
    
    tl.col = "black",
    tl.cex = 0.65,
    tl.srt = 45,
    
    cl.pos = "r",
    cl.cex = 0.65,
    cl.ratio = 0.08,
    cl.offset = 0.70
  )
}

tiff(
  filename = "corrplot_all_variables.tiff",
  width = 8,
  height = 7,
  units = "in",
  res = 400
)

draw_corrplot(plot_matrix)

dev.off()

#  VIF
if (!require(car)) install.packages("car")

library(car)

# VIF
# =================================================================
if (!require(car)) install.packages("car")
library(car)

vif_model <- lm(
  Policy ~ Standard +
    Policy_Standard +
    IndStructure +
    IndUpgrade +
    lnFirm +
    lnProd +
    lnInvest +
    lnDebt +
    lnProfit +
    RDIntensity +
    EduStructure,
  data = vars_all
)

vif_values <- vif(vif_model)

print(round(vif_values, 3))


















#Baseline model +2SRI model
#Baseline model 
# ========
library(fixest)
library(AER)
library(readxl)
library(dplyr)
library(car)
library(sandwich)


df <- read_excel("GB data.xlsx", sheet = "Sheet1") %>%
  mutate(
    province = as.factor(province),
    year = as.factor(year)
  ) %>%
  group_by(province) %>%
  arrange(year, .by_group = TRUE) %>%
  mutate(
    y            = y,
    policy       = Policy,
    match        = Standard,
    policy_lag2  = lag(policy, 2),
    match_lag2   = lag(match, 2),
    tts  = lag(tts, 0),
    inter_pm_lag = policy_lag2 * match_lag2,
    non_green_IV = lag(`non-green`, 2)
  ) %>%
  ungroup() %>%
  filter(!is.na(non_green_IV),
         !is.na(policy_lag2), !is.na(match_lag2))

df <- df %>%
  mutate(
    Firm = log(Firm),
    Prod = log(Prod),
    Debt = log(Debt),
    Invest = log(Invest),
    Profit  = log(Profit )
  )
df <- df %>%
  mutate(
  )

controls <- c("IndUpgrade", "IndStructure", "Firm", "Prod",
              "Debt", "Invest",
              "EduStructure", "RDIntensity", "Profit")

controls_rhs <- paste(controls, collapse = " + ")


# Policy only
fml_policy <- as.formula(
  paste0("y ~ policy_lag2 + ", controls_rhs, " | province + year")
)

# Standard only
fml_standard <- as.formula(
  paste0("y ~ match_lag2 + ", controls_rhs, " | province + year")
)

# Interaction
fml_interaction <- as.formula(
  paste0("y ~ policy_lag2 + match_lag2 + inter_pm_lag + ",
         controls_rhs, " | province + year")
)

#
model_policy <- fenegbin(
  fml_policy,
  data = df,
  cluster = ~ province + year
)
model_policy


model_standard <- fenegbin(
  fml_standard,
  data = df,
  cluster = ~ province + year
)
model_standard


model_interaction <- fenegbin(
  fml_interaction,
  data = df,
  cluster = ~ province + year
)
model_interaction
# ==========================









#2sri
# ====Instrumental variable for the interaction term (if necessary)====
df <- df %>%
  mutate(
    non_green_IV_match = non_green_IV * match_lag2
  )

#  First stage 
fml_stage1_policy <- as.formula(
  paste0("policy_lag2 ~ non_green_IV + ", controls_rhs, " | province + year")
)
stage1_policy <- feols(fml_stage1_policy, data = df, cluster = ~province+year)
summary(stage1_policy)

# Calculate the residuals and generate interaction residuals
df$u_policy_lag2 <- resid(stage1_policy)
df$u_policy_match <- df$u_policy_lag2 * df$match_lag2

# Weak Instrumental Variable Test
fml_iv <- as.formula(paste0(
  "y ~ policy_lag2 + inter_pm_lag + match_lag2 + ",
  controls_rhs,
  " | ", controls_rhs, " + match_lag2" , 
  " + non_green_IV + non_green_IV_match"
))
iv_model <- ivreg(fml_iv, data = df)
summary(iv_model, diagnostics = TRUE)

#（KP LM）identification
# (1) policy term
fml_stage1_policy_lm <- as.formula(
  paste0("policy_lag2 ~ non_green_IV + ", controls_rhs)
)
stage1_policy_lm <- lm(fml_stage1_policy_lm, data = df)
linearHypothesis(
  stage1_policy_lm,
  c("non_green_IV = 0"),
  vcov = vcovHC(stage1_policy_lm, type = "HC1")
)

# (2) interaction term
fml_stage1_inter_lm <- as.formula(
  paste0("inter_pm_lag ~ match_lag2 + non_green_IV_match + ", controls_rhs)
)
stage1_inter_lm <- lm(fml_stage1_inter_lm, data = df)
linearHypothesis(
  stage1_inter_lm,
  c("non_green_IV_match = 0"),
  vcov = vcovHC(stage1_inter_lm, type = "HC1")
)

# ====2SRI====
fml_2sri <- as.formula(paste0(
  "y ~ policy_lag2 + inter_pm_lag + match_lag2 +",
  controls_rhs, " + u_policy_lag2 + u_policy_match | province + year"
))
model_fml_2sri <- fenegbin(fml_2sri, data = df, cluster = ~province + year)
summary(model_fml_2sri)












#Robust checks
#1.Poisson
library(fixest)
library(readxl)
library(dplyr)
df <- read_excel("GB data.xlsx", sheet = "Sheet1") %>%
  mutate(
    province = as.factor(province),
    year = as.factor(year)
  ) %>%
  group_by(province) %>%
  arrange(year, .by_group = TRUE) %>%
  mutate(
    policy       = Policy,
    match        = Standard,
    policy_lag2  = lag(policy, 2),
    match_lag2   = lag(match, 2),
    inter_pm_lag = policy_lag2 * match_lag2,
    non_green_IV = lag(`non-green`, 2)
  ) %>%
  ungroup() %>%
  filter(!is.na(non_green_IV),
         !is.na(policy_lag2), !is.na(match_lag2))

df <- df %>%
  mutate(
    Firm = log(Firm),
    Prod = log(Prod),
    Debt = log(Debt),
    Invest = log(Invest),
    Profit  = log(Profit )
  )

controls <- c("IndUpgrade", "IndStructure", "Firm", "Prod",
              "Debt", "Invest",
              "EduStructure", "RDIntensity", "Profit")
controls_rhs <- paste(controls, collapse = " + ")

fml_stage1_policy <- as.formula(
  paste0("policy_lag2 ~ non_green_IV + ", controls_rhs, " | province + year")
)
stage1_policy <- feols(fml_stage1_policy, data = df, cluster = ~province + year)
df$u_policy_lag2 <- resid(stage1_policy)
df$u_policy_match <- df$u_policy_lag2 * df$match_lag2

fml_poisson <- as.formula(paste0(
  "y ~ policy_lag2 + inter_pm_lag + match_lag2 + ",
  controls_rhs, " + u_policy_lag2 + u_policy_match | province + year"
))

model_poisson <- fepois(fml_poisson, data = df, cluster = ~province + year)
summary(model_poisson)

#2.Alternative indicator
# change: Policy into Policy2

#3.δ = 0.15 or δ = 0.30
# change: Standard into Standard2 or Standard3










# Mechanism analysis
fml_mediator <- as.formula(paste0(
  "`tts` ~ policy_lag2 + match_lag2 + inter_pm_lag + ",
  controls_rhs, " + u_policy_lag2 + I(u_policy_lag2 * match_lag2) | province + year"
))
model_mediator <- feols(fml_mediator, data = df, cluster = ~province+year)
summary(model_mediator)





#Heterogeneity 

#region heterogeneity (re-estimating residuals for each region)
# east <- c("liaoning","beijing","tianjin","shanghai","hebei","shandong","jiangsu","zhejiang","fujian","guangdong","guangxi","hainan")
# central <- c("heilongjiang","jilin","shanxi","neimenggu","anhui","henan","hubei","hunan","jiangxi")
# west <- c("chongqing","sichuan","yunnan","guizhou","xizang","shaanxi","gansu","qinghai","ningxia","xinjiang")


#actors heterogeneity 
# change: y into Enterprise	or Individual	or Research institution











#Extended Analysis（lag 2 or 3）
library(readxl)
library(dplyr)
library(glmnet)
library(fixest)

df <- read_excel("GB data.xlsx", sheet = "Sheet1")

df <- df %>%
  group_by(province) %>%
  arrange(year, .by_group = TRUE) %>%
  mutate(
    lag2_D = lag(directional2, 2),
    lag2_T = lag(technical2, 2),
    lag2_F = lag(fiscal2, 2),
    lag2_S = lag(serviceoriented2, 2),
    lag2_R = lag(regulatory2, 2),
    lag2_M = lag(Standard, 2)
  ) %>%
  ungroup() %>%
  filter(!is.na(lag2_M))

#
df <- df %>%
  mutate(
    triple_D_T_F = lag2_D * lag2_T * lag2_F,
    triple_D_T_S = lag2_D * lag2_T * lag2_S,
    triple_D_T_R = lag2_D * lag2_T * lag2_R,
    triple_D_F_S = lag2_D * lag2_F * lag2_S,
    triple_D_F_R = lag2_D * lag2_F * lag2_R,
    triple_D_S_R = lag2_D * lag2_S * lag2_R,
    triple_T_F_S = lag2_T * lag2_F * lag2_S,
    triple_T_F_R = lag2_T * lag2_F * lag2_R,
    triple_T_S_R = lag2_T * lag2_S * lag2_R,
    triple_F_S_R = lag2_F * lag2_S * lag2_R
  )

#
df <- df %>%
  mutate(
    inter_D_T_F = lag2_M * triple_D_T_F,
    inter_D_T_S = lag2_M * triple_D_T_S,
    inter_D_T_R = lag2_M * triple_D_T_R,
    inter_D_F_S = lag2_M * triple_D_F_S,
    inter_D_F_R = lag2_M * triple_D_F_R,
    inter_D_S_R = lag2_M * triple_D_S_R,
    inter_T_F_S = lag2_M * triple_T_F_S,
    inter_T_F_R = lag2_M * triple_T_F_R,
    inter_T_S_R = lag2_M * triple_T_S_R,
    inter_F_S_R = lag2_M * triple_F_S_R
  )

# 
df <- df %>%
  mutate(
    Firm = log(Firm),
    Prod = log(Prod),
    Debt = log(Debt),
    Invest = log(Invest),
    Profit = log(Profit )
  )

#
controls <- c(
  "IndUpgrade","IndStructure","Firm","Prod",
  "Debt","Invest",
  "Profit","EduStructure","RDIntensity"
)

triples <- c(
  "triple_D_T_F","triple_D_T_S","triple_D_T_R","triple_D_F_S","triple_D_F_R",
  "triple_D_S_R","triple_T_F_S","triple_T_F_R","triple_T_S_R","triple_F_S_R"
)

interactions <- c(
  "inter_D_T_F","inter_D_T_S","inter_D_T_R","inter_D_F_S","inter_D_F_R",
  "inter_D_S_R","inter_T_F_S","inter_T_F_R","inter_T_S_R","inter_F_S_R"
)

main_vars <- c("lag2_D","lag2_T","lag2_F","lag2_S","lag2_R","lag2_M")

x_vars <- c(main_vars, triples, interactions, controls)

# 
df_lasso <- df %>%
  dplyr::select(y, province, year, dplyr::all_of(x_vars)) %>%
  filter(if_all(all_of(x_vars), ~ is.finite(.))) %>%
  filter(is.finite(y))

#
X <- as.matrix(df_lasso[, x_vars])
y <- df_lasso$y

#
set.seed(123)
cvfit <- cv.glmnet(
  X, y,
  family = "poisson",
  alpha = 1,
  standardize = TRUE
)

#
selected_vars <- rownames(coef(cvfit, s = "lambda.min"))[
  coef(cvfit, s = "lambda.min")[, 1] != 0
]
selected_vars <- setdiff(selected_vars, "(Intercept)")

print(selected_vars)

#
hier_map <- c(
  inter_D_T_F = "triple_D_T_F",
  inter_D_T_S = "triple_D_T_S",
  inter_D_T_R = "triple_D_T_R",
  inter_D_F_S = "triple_D_F_S",
  inter_D_F_R = "triple_D_F_R",
  inter_D_S_R = "triple_D_S_R",
  inter_T_F_S = "triple_T_F_S",
  inter_T_F_R = "triple_T_F_R",
  inter_T_S_R = "triple_T_S_R",
  inter_F_S_R = "triple_F_S_R"
)

extra_triples <- unname(hier_map[names(hier_map) %in% selected_vars])
selected_vars_final <- union(selected_vars, extra_triples)

print(selected_vars_final)

#
fml_post <- as.formula(
  paste("y ~", paste(selected_vars_final, collapse = " + "), "| province + year")
)

post_lasso_model1 <- fenegbin(fml_post, data = df_lasso)

summary(post_lasso_model1, cluster = ~province + year)












# How to get "Poliy".
#PCA policy comprehensiveness
if(!require(readxl)) install.packages("readxl")
if(!require(dplyr)) install.packages("dplyr")

library(readxl)
library(dplyr)

#
df <- read_excel("PCA.xlsx", sheet = "Sheet1")


#
policy_vars <- df %>%
  dplyr::select(`technical`, `directional`, `serviceoriented`, `regulatory`, `fiscal`)


#
pca_result <- prcomp(policy_vars, center = TRUE, scale. = TRUE)

#
print(pca_result$rotation)
print(summary(pca_result))

#
df$policy <- pca_result$x[,1]

#
head(df)


